import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;

public class Theatre {

    public static void main(String[] args) {

        int[][] seats = initialize_seats_array();

        ArrayList<Ticket> tickets = new ArrayList<>();

        show_welcome_message();

        while (true) {
            show_menu();

            int option = get_integer_input("Option", 0, 8);

            switch (option) {
                case 0:
                    show_closing_message();
                    return;
                case 1:
                    buy_ticket(seats, tickets);
                    break;
                case 2:
                    print_seating_area(seats);
                    break;
                case 3:
                    cancel_ticket(seats, tickets);
                    break;
                case 4:
                    show_available(seats);
                    break;
                case 5:
                    save("data.txt", seats);
                    break;
                case 6:
                    load("data.txt", seats);
                    break;
                case 7:
                    show_tickets_info(tickets);
                    break;
                case 8:
                    ArrayList<Ticket> copyOfTickets = new ArrayList<>(tickets);
                    ArrayList<Ticket> sortedTicketsByPriceAscending = sort_tickets(copyOfTickets);
                    show_tickets_info(sortedTicketsByPriceAscending);
                    break;
            }
        }
    }

    public static void buy_ticket(int[][] seats, ArrayList<Ticket> tickets) {
        int row = get_integer_input("Row", 1, 3);

        int seat = get_integer_input("Seat", 1, seats[row - 1].length);

        if (seats[row - 1][seat - 1] == 1) {
            System.out.println("Seat " + seat + " in Row " + row + " is already occupied.");
            return;
        }

        seats[row - 1][seat - 1] = 1;

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = scanner.nextLine();

        System.out.print("Enter surname: ");
        String surname = scanner.nextLine();

        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        System.out.print("Enter price: ");
        while (!scanner.hasNextDouble()) {
            System.out.println("That's not a number! Please enter a number.");
            scanner.nextLine();
        }
        double price = scanner.nextDouble();


        Person person = new Person(name, surname, email);
        Ticket ticket = new Ticket(row, seat, price, person);
        tickets.add(ticket);

        System.out.println("Seat " + seat + " in Row " + row + " has been sold successfully.");
    }

    public static void print_seating_area(int[][] seats) {

        System.out.println("     ***********");
        System.out.println("     *  STAGE  *");
        System.out.println("     ***********");

        for (int i = 0; i < seats.length; i++) {
            String rowString = "";

            if (i == 0) {
                rowString += "    ";
            }
            else if (i == 1) {
                rowString += "  ";
            }

            for (int j = 0; j < seats[i].length; j++) {
                if (seats[i][j] == 0) {
                    rowString += "O";
                }
                else {
                    rowString += "X";
                }
                if (j == seats[i].length / 2 - 1) {
                    rowString += " ";
                }
            }

            System.out.println(rowString);
        }
    }

    public static void cancel_ticket(int[][] seats, ArrayList<Ticket> tickets) {
        int row = get_integer_input("Row", 1, 3);

        int seat = get_integer_input("Seat", 1, seats[row - 1].length);

        if (seats[row - 1][seat - 1] == 0) {
            System.out.println("Seat " + seat + " in Row " + row + " has not been sold.");
            return;
        }

        seats[row - 1][seat - 1] = 0;

        for (int i = 0; i < tickets.size(); i++) {
            Ticket ticket = tickets.get(i);
            if (ticket.get_row() == row && ticket.get_seat() == seat) {
                tickets.remove(i);
                break;
            }
        }

        System.out.println("Seat " + seat + " in Row " + row + " is now available.");
    }

    public static void show_available(int[][] seats) {
        for (int row = 0; row < seats.length; row++) {
            System.out.print("Seats available in Row " + (row + 1) + ": ");

            for (int seat = 0; seat < seats[row].length; seat++) {
                if (seats[row][seat] == 0) {
                    System.out.print((seat + 1) + " ");
                }
            }

            System.out.println();
        }
    }

    public static void save(String fileName, int[][] seats) {
        try {
            File file = new File(fileName);
            FileWriter writer = new FileWriter(file);

            for (int i = 0; i < seats.length; i++) {
                for (int j = 0; j < seats[i].length; j++) {
                    writer.write(seats[i][j] + " ");
                }
                writer.write("\n");
            }

            writer.close();
            System.out.println("File saved successfully!");
        }
        catch (IOException e) {
            System.out.println("An error occurred while saving the file.");
            e.printStackTrace();
        }
    }

    public static void load(String fileName, int[][] seats) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);

            int row = 0;
            while (scanner.hasNextLine() && row < seats.length) {
                String line = scanner.nextLine();
                String[] tokens = line.split(" ");
                for (int col = 0; col < tokens.length && col < seats[row].length; col++) {
                    seats[row][col] = Integer.parseInt(tokens[col]);
                }

                row++;
            }

            scanner.close();
            System.out.println("File has been loaded successfully !");
        }
        catch (FileNotFoundException e) {
            System.out.println("File not found: " + fileName);
        }
        catch (NumberFormatException e) {
            System.out.println("Invalid number format in file: " + fileName);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void show_tickets_info(ArrayList<Ticket> tickets){
        double totalPrice = 0.0;

        for (int i = 0; i < tickets.size(); i++) {
            Ticket ticket = tickets.get(i);
            ticket.print();
            totalPrice += ticket.get_price();
        }

        System.out.println("Total price of tickets is: £" + totalPrice);
    }

    public static ArrayList<Ticket> sort_tickets(ArrayList<Ticket> tickets){
        Comparator<Ticket> comp = new Comparator<Ticket>() {
            @Override
            public int compare(Ticket ticket1, Ticket ticket2) {
                return Double.compare(ticket1.get_price(), ticket2.get_price());
            }
        };

        tickets.sort(comp);

        return tickets;
    }

    public static int[][] initialize_seats_array(){
        int[][] seats = {
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };

        return seats;
    }

    public static void show_welcome_message(){
        System.out.println("\n**************************************************");
        System.out.println("Welcome to the New Theatre !");
        System.out.println("**************************************************");
    }

    public static void show_closing_message(){
        System.out.println("\n**************************************************");
        System.out.println("Thank you for using the Theatre system. Goodbye!");
        System.out.println("**************************************************");
    }

    public static void show_menu(){
        System.out.println("\n--------------------------------------------------");
        System.out.println("Please select an option:");
        System.out.println("1) Buy a ticket");
        System.out.println("2) Print seating area");
        System.out.println("3) Cancel ticket");
        System.out.println("4) List available seats");
        System.out.println("5) Save to file");
        System.out.println("6) Load from file");
        System.out.println("7) Print ticket information and total price");
        System.out.println("8) Sort tickets by price");
        System.out.println("0) Quit");
        System.out.println("--------------------------------------------------");
    }

    public static int get_integer_input(String inputName, int start, int end) {
        Scanner scanner = new Scanner(System.in);

        int userInput;

        while (true) {
            try {
                System.out.print("Enter " + inputName + ": ");

                userInput = Integer.parseInt(scanner.nextLine());

                if (userInput < start || userInput > end) {
                    throw new Exception();
                }

                break;
            }
            catch (Exception e) {
                System.out.println(inputName + " not valid. Please enter (" + start + "-" + end + ") !");
            }
        }

        return userInput;
    }
}
