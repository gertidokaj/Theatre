public class Ticket {
    private int row;
    private int seat;
    private double price;
    private Person person;

    public Ticket(int row, int seat, double price, Person person) {
        this.row = row;
        this.seat = seat;
        this.price = price;
        this.person = person;
    }

    public int get_row() {
        return row;
    }

    public void set_row(int row) {
        this.row = row;
    }

    public int get_seat() {
        return seat;
    }

    public void set_seat(int seat) {
        this.seat = seat;
    }

    public double get_price() {
        return price;
    }

    public void set_price(double price) {
        this.price = price;
    }

    public Person get_person() {
        return person;
    }

    public void set_person(Person person) {
        this.person = person;
    }

    public void print() {
        System.out.println("***************** Ticket details *****************");
        System.out.println("Surname, name (email): " + person.get_surname() + ", " + person.get_name() + " (" + person.get_email() + ")");
        System.out.println("Row: " + row);
        System.out.println("Seat: " + seat);
        System.out.println("Price: " + price);
    }
}
